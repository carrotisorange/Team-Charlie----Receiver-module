/*
 *  Document   : index
    Created on : 05 9, 16, 6:04:54 AM
    Author     : Team Charlie
 */

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LENOVO
 */
public class Validate extends HttpServlet {
    Connection con = null;
    String email = null;
    String status = null;

  public void init(){
     
          try {
              Class.forName("com.mysql.jdbc.Driver");
          } catch (ClassNotFoundException ex) {
              Logger.getLogger(Validate.class.getName()).log(Level.SEVERE, null, ex);
          }
            try{
                con = DriverManager.getConnection("jdbc:mysql://localhost/dbase?" + "user=root&password=");
                }
            catch(SQLException ex){
                System.out.println("SQLException: " + ex.getMessage());
                System.out.println("SQLState: " + ex.getSQLState());
                System.out.println("VendorError: " + ex.getErrorCode());
      }
  }
  
  public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
       try {
           email=request.getParameter("email");
           status=request.getParameter("status");
           String q = "select * from fname from users where status = "+status+"" ;
           Statement stmt = con.createStatement();
           ResultSet result = stmt.executeQuery(q);
           String useremail=null;
           String userstatus=null;
           
           while(result.next()){
               useremail=result.getString(3);
                userstatus=result.getString(7);
           }
           
           if(useremail.equals(email)&&userstatus.equals(status)){
               System.out.println("Sucess!");
           }
           else{
               System.out.println("Failed!");
           }
       }   
       
       catch(Exception e){
           
       }
  }
}
