import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;

public class Validate
 {
     public static boolean checkUser(String email,String pass) throws NoSuchAlgorithmException 
     {
         String md5 = "";
         MessageDigest mdEnc = MessageDigest.getInstance("MD5"); // Encryption algorithm
         mdEnc.update(pass.getBytes(), 0, pass.length());
         md5 = new BigInteger(1, mdEnc.digest()).toString(16); // Encrypted string
         
      boolean st =false;
      try{

	 //loading drivers for mysql
         Class.forName("com.mysql.jdbc.Driver");

 	 //creating connection with the database 
         Connection con=DriverManager.getConnection
                        ("jdbc:mysql://localhost:3306/dbase","root","");
         PreparedStatement ps =con.prepareStatement
                         ("select * from users where email=? and password=?");
         ps.setString(1, email);
         ps.setString(2, md5);
         ResultSet rs =ps.executeQuery();
         st = rs.next();
        
      }catch(ClassNotFoundException e)
      {
      }  catch (SQLException e) {
         }
         return st;                 
  }   
}