import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class Login extends HttpServlet {
 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String email = request.getParameter("email");
        String password = request.getParameter("password");
  
        try {
            if(Validate.checkUser(email, password))
            {
                Cookie emailCookie = new Cookie("email",email);
                //setting cookie to expiry in 30 mins
                emailCookie.setMaxAge(30*60);
                response.addCookie(emailCookie);
                response.sendRedirect("home.jsp");
            }
            
           
            else
            {
                RequestDispatcher rs = request.getRequestDispatcher("wrongcredentials.jsp");
                rs.include(request, response); 
            }
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
}