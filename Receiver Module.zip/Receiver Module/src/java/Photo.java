/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author LENOVO
 */
public class Photo extends HttpServlet {

 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    final String DB_URL = "jdbc:mysql://localhost/dbase";
    final String User = "root";
    final String Password = "";
    try {
        Class.forName(JDBC_DRIVER);
        Connection conn = DriverManager.getConnection(DB_URL, User, Password);

        PreparedStatement stmt = conn.prepareStatement("select prod_image from products where prodid=?");
        stmt.setLong(1, Long.valueOf(request.getParameter("prodid")));
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            response.getOutputStream().write(rs.getBytes("prod_image"));
        }
        conn.close();
    } catch (ClassNotFoundException e) {
    }   catch (SQLException e) {
        } catch (NumberFormatException e) {
        }
}

}

